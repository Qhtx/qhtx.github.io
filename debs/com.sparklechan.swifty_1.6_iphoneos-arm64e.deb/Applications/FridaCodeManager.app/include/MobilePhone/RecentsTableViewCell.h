#import <UIKit/UITableViewCell.h>

@class RecentCall;

@interface RecentsTableViewCell : UITableViewCell

- (RecentCall *)call;

@end
