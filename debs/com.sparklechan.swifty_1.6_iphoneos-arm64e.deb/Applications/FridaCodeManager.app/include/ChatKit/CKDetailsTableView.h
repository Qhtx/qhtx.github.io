#import <UIKit/UITableView.h>

@interface CKDetailsTableView : UITableView

@end
