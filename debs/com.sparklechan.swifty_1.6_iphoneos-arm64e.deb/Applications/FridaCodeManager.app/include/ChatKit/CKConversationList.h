#import <Foundation/NSObject.h>
#import <Foundation/NSArray.h>

@interface CKConversationList : NSObject {
	NSMutableArray *_trackedConversations;
}

@end
