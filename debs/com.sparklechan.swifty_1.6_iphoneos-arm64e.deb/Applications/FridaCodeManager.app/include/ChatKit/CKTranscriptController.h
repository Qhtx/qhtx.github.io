#import "CKScrollViewController.h"

@class CKConversation;

@interface CKTranscriptController : CKScrollViewController

@property (nonatomic, retain) CKConversation *conversation;

@end
