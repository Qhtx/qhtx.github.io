#import <UIKit/UIWindow+Private.h>

@interface FBWindow : UIWindow

@end