#import <UIKit/UIViewController.h>

@interface SBLockScreenViewController : UIViewController

@end
