#import <UIKit/UIViewController.h>

@interface SBNotificationsModeViewController : UIViewController

@end
