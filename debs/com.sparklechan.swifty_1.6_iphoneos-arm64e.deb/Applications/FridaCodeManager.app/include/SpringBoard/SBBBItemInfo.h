#import <Foundation/NSObject.h>

@interface SBBBItemInfo : NSObject

@end
