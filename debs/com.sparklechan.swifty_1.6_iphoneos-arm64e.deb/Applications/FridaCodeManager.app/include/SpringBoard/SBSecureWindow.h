#import "SBWindow.h"

@interface SBSecureWindow : SBWindow

+ (BOOL)_isSecure;

@end