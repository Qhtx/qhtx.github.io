#import <Foundation/NSObject.h>

@class BBBulletin;

@interface SBBulletinBannerItem : NSObject

- (BBBulletin *)seedBulletin;

@end
