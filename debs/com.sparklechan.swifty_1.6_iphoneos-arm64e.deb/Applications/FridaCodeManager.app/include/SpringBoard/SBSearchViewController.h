#import <Foundation/NSObject.h>

@interface SBSearchViewController : NSObject

+ (instancetype)sharedInstance;

@property BOOL isVisible;

@end
