#import "SBFolderController.h"

@class SBRootFolderView;

@interface SBRootFolderController : SBFolderController

@property (nonatomic, retain, readonly) SBRootFolderView *contentView;

@end
