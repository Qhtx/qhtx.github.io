#import <Foundation/Foundation.h>

@interface SBStatusBarController : NSObject

@end
