#import <Foundation/NSObject.h>

@interface SBStatusBarContentsView : NSObject

@end
