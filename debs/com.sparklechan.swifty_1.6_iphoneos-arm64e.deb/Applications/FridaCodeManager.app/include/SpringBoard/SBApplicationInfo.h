#import <FrontBoard/FBApplicationInfo.h>

API_AVAILABLE(ios(9.3))
@interface SBApplicationInfo : FBApplicationInfo
@end