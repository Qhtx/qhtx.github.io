#import <UIKit/UIViewController.h>

@interface SBDeckSwitcherViewController : UIViewController

@end
