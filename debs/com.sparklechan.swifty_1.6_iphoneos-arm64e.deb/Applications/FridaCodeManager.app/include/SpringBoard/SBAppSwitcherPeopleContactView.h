#import "SBAppSwitcherPeopleButtonAndLabelView.h"

@interface SBAppSwitcherPeopleContactView : SBAppSwitcherPeopleButtonAndLabelView

@end
