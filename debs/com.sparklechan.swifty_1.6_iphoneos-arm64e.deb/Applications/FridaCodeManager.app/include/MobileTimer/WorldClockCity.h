#import <Foundation/Foundation.h>

// framework

@interface WorldClockCity : NSObject

@property (readonly) NSString *name;

@end
