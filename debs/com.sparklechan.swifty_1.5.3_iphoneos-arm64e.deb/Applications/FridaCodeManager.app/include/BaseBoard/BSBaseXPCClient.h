#import <Foundation/NSObject.h>

@interface BSBaseXPCClient : NSObject

@end
