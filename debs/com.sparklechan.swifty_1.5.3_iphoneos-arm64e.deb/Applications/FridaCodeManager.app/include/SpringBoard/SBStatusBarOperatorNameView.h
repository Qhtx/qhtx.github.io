#import <Foundation/NSObject.h>

@interface SBStatusBarOperatorNameView : NSObject

@end
