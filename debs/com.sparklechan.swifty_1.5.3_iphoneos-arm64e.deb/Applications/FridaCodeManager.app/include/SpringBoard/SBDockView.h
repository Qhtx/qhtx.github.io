#import <UIKit/UIView.h>

@interface SBDockView : UIView

- (void)setBackgroundAlpha:(CGFloat)backgroundAlpha;

@end
