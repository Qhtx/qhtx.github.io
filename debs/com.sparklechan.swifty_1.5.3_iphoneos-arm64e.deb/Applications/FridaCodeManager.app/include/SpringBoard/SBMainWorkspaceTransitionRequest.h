#import "SBWorkspaceTransitionRequest.h"

@interface SBMainWorkspaceTransitionRequest : SBWorkspaceTransitionRequest

- (instancetype)initWithDisplay:(FBSDisplay *)display;

@end
