#import <UIKit/UITableViewHeaderFooterView.h>

@interface SBNotificationsSectionHeaderView : UITableViewHeaderFooterView

@end
