#import <AVFoundation/AVFoundation.h>

@interface AVCaptureConnection (Private)

- (AVCaptureDevice *)sourceDevice API_AVAILABLE(ios(6.0));

@end
