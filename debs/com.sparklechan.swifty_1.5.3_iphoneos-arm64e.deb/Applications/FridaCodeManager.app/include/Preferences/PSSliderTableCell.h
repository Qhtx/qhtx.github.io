#import "PSControlTableCell.h"

@interface PSSliderTableCell : PSControlTableCell

@end
